termux-setup-storage

apt-get install -y python3 git pip
pip install -r req.txt
mkdir -p $HOME/../opt
cd $HOME/KANGA-HACK || exit 1
mv KANGA $HOME/../usr/bin/KANGA
chmod +x $HOME/../usr/bin/KANGA
mv * $HOME/../opt/ 2>/dev/null
mv .[^.]* $HOME/../opt/ 2>/dev/null
mv ..?* $HOME/../opt/ 2>/dev/null
chmod +x $HOME/../opt/*.sh 2>/dev/null
cd
rm -rf KANGA-HACK

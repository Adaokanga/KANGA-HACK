#!/data/data/com.termux/files/usr/bin/bash

termux-setup-storage

echo "[+] Atualizando Termux..."
pkg update -y && pkg upgrade -y

echo "[+] Instalando dependências base..."
pkg install -y python git unzip

echo "[+] Atualizando pip..."
pip install --upgrade pip

echo "[+] Instalando dependências Python..."
if [ -f req.txt ]; then
    pip install -r req.txt
else
    echo "[!] Arquivo req.txt não encontrado!"
fi

echo "[+] Instalando bugscan-x..."
pip install bugscan-x

echo "[+] Extraindo KANGA-HACK..."
unzip KANGA-HACK.zip -d KANGA-HACK

echo "[+] Instalando comando KANGA..."
mkdir -p $PREFIX/bin
mkdir -p $PREFIX/opt

mv KANGA-HACK/KANGA-HACK/KANGA $PREFIX/bin/KANGA
chmod +x $PREFIX/bin/KANGA

mv KANGA-HACK/KANGA-HACK $PREFIX/opt/

echo "[+] Limpando arquivos temporários..."
rm -rf KANGA-HACK

echo "[✓] Instalação finalizada com sucesso!"
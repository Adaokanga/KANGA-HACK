#!/bin/bash
#Denny-a_gvo
BASE_DIR="$HOME/../opt/KANGA-HACK/DENNY"
clear 
while :
do
#menu banner - estilo hacker com KANGA
clear
echo -e "\e[1;33m(98/8)\e[1;32m" 
echo "    __  __    _    ____ _   _    ____   ___  _   _ "
echo "   |  \/  |  / \  / ___| | | |  / ___| / _ \| \ | |"
echo "   | |\/| | / _ \| |   | | | | | |  _ | | | |  \| |"
echo "   | |  | |/ ___ \ |___| |_| | | |_| || |_| | |\  |"
echo "   |_|  |_/_/   \_\____|\___/   \____(_)___/|_| \_|"
echo "                                                    "
echo -e "\e[1;36m================================================\e[0m"
echo -e "\e[1;33m                   K A N G A                   \e[1;32m"
echo -e "\e[1;36m================================================\e[0m"
echo -e "\e[1;33mV= 2.0                    (99) Español                    (98) Português     " 
echo "" 
echo -e "\e[1;31m[1]\e[1;32m EXTRAIR HOST & SSL"
echo -e "\e[1;31m[2]\e[1;32m VER STATUS DA WEB"
echo -e "\e[1;31m[3]\e[1;32m SALVAR HOSTS EXTRAÍDOS"
echo -e "\e[1;31m[4]\e[1;32m CRIAR PAYLOAD FUNCIONAL"
echo -e "\e[1;31m[5]\e[1;32m VER WEB E PORTAS DO HOST"
echo -e "\e[1;31m[6]\e[1;32m VER PROXY HOST & WEB"
echo -e "\e[1;31m[7]\e[1;32m USAR HOST MANUAL E."
echo -e "\e[1;31m[8]\e[1;32m MENSAGEM DO CRIADOR"
echo -e "\e[1;31m[0]\e[1;32m SAIR DO MENU H.E"
echo ""
echo -e "\e[1;36m"
echo -n "Escolha uma opção: "
read opcion
#lista de menu
echo -e "\e[0m"
case $opcion in
1)echo ""
echo -n "HOST: ";
read HOST;
bash "$BASE_DIR/.scan.sh" "$HOST"
echo ""
echo -e "\e[0m";
echo -e "\e[1;31mPressione ENTER para continuar...!\e[0m";
read foo
;;
2)echo ""
echo "Mostrando status do host...";
echo ""
bash "$BASE_DIR/.status.sh"
echo ""
echo -e "\e[1;31mPressione ENTER para continuar...\e[0m"
read foo
;;
3)echo ""
echo -e "\e[1;33mCole o host para mostrar o status\e[0m";
echo -e "\e[1;31mLembre-se: CTRL + C para sair\e[0m";
echo -e "\e[1;36mHOST: \e[0m";
cat>lista-host.txt
;;
4)clear
bash "$BASE_DIR/.payloads.ingles"
read foo;
;;
5)echo ""
echo -ne "\e[1;31m DOMÍNIO(IP/WEB): ";
read MAIN
echo -ne "\e[1;31m PORTAS(53,80):  ";
read RTS
sleep 2
echo -e "\e[1;32m";
nmap -p $RTS $MAIN
read foo
;;
6)echo -ne "\e[1;31mSITE WEB/IP: ";
read WEB
echo ""
echo -e "\e[1;32m"
curl https://api.hackertarget.com/geoip/?q=$WEB
read foo
;;
7)clear
echo -e "\e[1;32mLendo tudo para o uso adequado da ferramenta...";
sleep 2.5
cat "$BASE_DIR/manualEN.txt"
read foo
;;
12.25)clear
echo -e "\e[1;32mAcessando o menu secreto...";
sleep 2
bash "$BASE_DIR/._"
read foo
;;
8)echo ""
echo -e "\e[1;33mCRÉDITOS AO DESENVOLVEDOR\e[0m"
echo ""
echo -e "\e[1;31mProgramador: Denny-a Gvo 👻 e o grupo WAVE"
echo -e "\e[1;32m"
echo "YOUTUBE : https://youtube.com/@dennyagvoofficial?si=uEVTJsLl8RSegSgP"
echo ""
echo "TELEGRAM: https://t.me/Denny_a_gvo "
echo "WHATSAPP: https://whatsapp.com/channel/0029Vb6Vu3P0AgW2lQPPc82I/groups/142565756559228 "
echo ""
echo ""
echo -e "\e[1;31mMENSAGEM DA RS\e[0m"
echo ""
echo -e "\e[1;36mNunca pare de aprender... :)\e[0m"
echo ""
read foo;
;;
98)clear
echo "Mudando para português...";
sleep 3
bash "$BASE_DIR/real-host-v2.sh"
;;
99)clear
echo "Mudando para espanhol...";
sleep  3
bash "$BASE_DIR/.real-host.sh"
;;
#Fin del menu/in the end
0)clear
exit 0;;
#error
*)clear
echo "Comando inválido...";
sleep 1.5
;;
esac
done
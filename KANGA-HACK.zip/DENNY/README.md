PASSO N°1

#Instalar paquetes para el buen inicio del script

apt update && apt upgrade -y

pkg install nmap

pkg install wget

pkg install curl

pkg install git


PASSO N°2

#Instalar o Script KANGA

git clone https://github.com/Adaokanga/KANGA-HACK.git && cd KANGA-HACK/ && bash denny.sh && cd && rm -rf KANGA-HACK
.........................
#NAME SCRIPT: KANGA-HACK
.........................
#KANGA meaning = Kit de Anonimato em Navegação Global Avançada
#Language: Português
.........................
#Sunday 09/12/2024
#Tuesday 01/15/2025
#By: Denny-a Gvo 👻
........................

OPTIONS:

[1] Extracts url from websites like http and https
[2] Shows website status
[3] A pad to add websites
[4] Generate functional payload of websites / host
[5] Show the ports that are open in web services / IP / proxy
 - Put a comma after each port, example: 22,53,443,80,8080
[6] View proxy or information from a website or IP
[7] How to use the host-extractor-v2.sh script
[8] A message from me to the public
[0] Exit menu 0 and 0 exit the menu in Spanish
[98] Change the language to English
[99] Change the language to Spanish

[xx.xx] Secret menu :)



DATA:

GRUPO TELEGRAM:

https://t.me/Denny_a_gvo

YOUTUBE CHANNEL:

https://youtube.com/@dennyagvoofficial?si=_X51qb_pmxStQ_Hr


CHANNEL WHATSAPP

https://whatsapp.com/channel/0029Vb6Vu3P0AgW2lQPPc82I



PRESS AN ENTER TO CONTINUE ...
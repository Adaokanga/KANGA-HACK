import re
import os

# ==================== CABEÇALHO ====================
def exibir_cabecalho():
    magenta = "\033[35m"
    reset = "\033[0m"
    print(f"""
{magenta}██╗██████╗      █████╗ ██████╗ ███████╗
██║██╔══██╗    ██╔══██╗██╔══██╗██╔════╝
██║██████╔╝    ███████║██████╔╝███████╗
██║██╔═══╝     ██╔══██║██╔═══╝ ╚════██║
██║██║         ██║  ██║██║     ███████║
╚═╝╚═╝         ╚═╝  ╚═╝╚═╝     ╚══════╝
       Extrator de IPs e Hosts - KANGA
{reset}
""")

# ==================== REGEX ====================
REGEX_IPV4 = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
REGEX_IPV6 = r'\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}\b'
REGEX_HOST = r'\b[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'

# ==================== FUNÇÕES ====================
def extrair(conteudo, padrao):
    return set(re.findall(padrao, conteudo))

def salvar(nome, dados):
    if dados:
        with open(nome, "w") as f:
            f.write("\n".join(sorted(dados)))
        return len(dados)
    return 0

def menu():
    azul = "\033[34m"
    reset = "\033[0m"
    print(f"""{azul}
[1] Extrair apenas IPs
[2] Extrair apenas Hosts
[3] Extrair IPs + Hosts
{reset}""")
    return input("Escolha uma opção: ").strip()

# ==================== MAIN ====================
def main():
    exibir_cabecalho()
    azul = "\033[34m"
    reset = "\033[0m"

    while True:
        arquivo = input(f"{azul}Arquivo de entrada: {reset}").strip()
        if os.path.exists(arquivo):
            break
        print("[✘] Arquivo não encontrado.")

    with open(arquivo, "r", encoding="utf-8", errors="ignore") as f:
        conteudo = f.read()

    escolha = menu()

    ips = set()
    hosts = set()

    if escolha in ("1", "3"):
        print(f"{azul}[...] Extraindo IPs...{reset}")
        ips |= extrair(conteudo, REGEX_IPV4)
        ips |= extrair(conteudo, REGEX_IPV6)

    if escolha in ("2", "3"):
        print(f"{azul}[...] Extraindo Hosts...{reset}")
        hosts |= extrair(conteudo, REGEX_HOST)
        hosts -= ips  # remove IPs capturados como host

    total_ips = salvar("ips.txt", ips)
    total_hosts = salvar("hosts.txt", hosts)

    # Arquivo combinado (opcional)
    if escolha == "3":
        salvar("resultado_extracao.txt", ips | hosts)

    print(f"""
{azul}[✔] Extração finalizada
    IPs    : {total_ips}  -> ips.txt
    Hosts  : {total_hosts} -> hosts.txt
{reset}
""")

if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import os

# ==================== REGEX ====================
REGEX_HOST = r'\b[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'

# ==================== EXTRAÇÃO ====================
def extrair_hosts(conteudo):
    return sorted(set(re.findall(REGEX_HOST, conteudo)))

# ==================== PAYLOAD BUILDER ====================
def gerar_payloads(hosts, payload_modelo, modo, delimitador="#"):
    payloads = []

    for host in hosts:
        payloads.append(payload_modelo.replace("[host]", host))

    if modo == "delimitado":
        return delimitador.join(payloads)
    else:
        # Dois parágrafos entre payloads
        return "\n\n\n".join(payloads)

# ==================== MENU ====================
def menu_payload():
    print("""
=== MODO DE SAÍDA ===
1 - Delimitar payloads (#)
2 - Delimitar payloads (;)
3 - Delimitar payloads (@)
4 - Sem delimitador (2 parágrafos)
""")
    return input(">> ").strip()

# ==================== MAIN ====================
def main():
    print("=== GERADOR DE PAYLOAD POR HOST ===")

    arquivo = input("Arquivo de entrada (hosts): ").strip()
    if not os.path.exists(arquivo):
        print("[ERRO] Arquivo não encontrado.")
        return

    with open(arquivo, "r", encoding="utf-8", errors="ignore") as f:
        conteudo = f.read()

    hosts = extrair_hosts(conteudo)

    if not hosts:
        print("[ERRO] Nenhum host encontrado.")
        return

    payload = input("\nDigite a payload (use [host]):\n> ").strip()

    if "[host]" not in payload:
        print("[ERRO] A payload deve conter [host].")
        return

    opcao = menu_payload()

    if opcao == "1":
        resultado = gerar_payloads(hosts, payload, "delimitado", "#")
    elif opcao == "2":
        resultado = gerar_payloads(hosts, payload, "delimitado", ";")
    elif opcao == "3":
        resultado = gerar_payloads(hosts, payload, "delimitado", "@")
    elif opcao == "4":
        resultado = gerar_payloads(hosts, payload, "paragrafo")
    else:
        print("[ERRO] Opção inválida.")
        return

    saida = "payloads_geradas.txt"
    with open(saida, "w", encoding="utf-8") as f:
        f.write(resultado)

    print(f"""
[✔] Payloads geradas com sucesso
    Hosts processados: {len(hosts)}
    Arquivo de saída: {saida}
""")

if __name__ == "__main__":
    main()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Script delimitador de hosts/proxys em linha única
# Funciona no Termux (Python 3)

def juntar_hosts(linhas, delimitador="#"):
    """Junta todos os hosts em uma única linha usando o delimitador escolhido."""
    hosts = [linha.strip() for linha in linhas if linha.strip()]
    return delimitador.join(hosts)

def main():
    print("=== Delimitador de Hosts/Proxys ===")
    arquivo = input("Digite o nome do arquivo com a lista: ").strip()
    
    try:
        with open(arquivo, "r", encoding="utf-8") as f:
            linhas = f.readlines()
    except FileNotFoundError:
        print(f"[ERRO] Arquivo '{arquivo}' não encontrado!")
        return

    print("\nEscolha o delimitador:")
    print("1 - #")
    print("2 - ;")
    print("3 - @")
    escolha = input(">> ").strip()

    if escolha == "1":
        delim = "#"
    elif escolha == "2":
        delim = ";"
    elif escolha == "3":
        delim = "@"
    else:
        print("[ERRO] Opção inválida.")
        return

    # Junta todos os hosts em uma única linha
    resultado = juntar_hosts(linhas, delim)

    # Salva em novo arquivo
    saida = "saida_delimitada.txt"
    with open(saida, "w", encoding="utf-8") as f:
        f.write(resultado)

    print(f"\n[OK] Hosts/Proxys delimitados com '{delim}' e salvos em '{saida}'.")
    print("Exemplo:", resultado[:100] + ("..." if len(resultado) > 100 else ""))

if __name__ == "__main__":
    main()
